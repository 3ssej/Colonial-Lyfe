class BasicGroupUserSerializer < ApplicationSerializer
  attributes :group_id, :user_id, :notification_level
end
