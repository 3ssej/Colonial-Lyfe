class UserAuthTokenLog < ActiveRecord::Base
end
