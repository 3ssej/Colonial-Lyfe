//= require template_include.js
//= require select2.js
//= require jquery.ui.widget.js
//= require jquery.fileupload.js
//= require sweetalert.js
