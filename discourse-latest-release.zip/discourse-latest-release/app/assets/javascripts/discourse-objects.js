window.Discourse = {};
Discourse.SiteSettings = {};
