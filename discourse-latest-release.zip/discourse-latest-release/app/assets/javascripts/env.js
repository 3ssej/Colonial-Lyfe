window.ENV = { };
window.EmberENV = window.EmberENV || {};
window.EmberENV.FORCE_JQUERY = true;
